# Kalakaar Backend

Ready backend files for Kalakaar.

Environment variables:
MONGODB_URI
JWT_SECRET
PORT (optional)

API:
GET /
GET /api/health
POST /api/auth/signup
POST /api/auth/login

Never commit real credentials or a real .env file.
